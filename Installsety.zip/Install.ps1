$ErrorActionPreference = 'Stop'
$installerPath = Join-Path -Path $PSScriptRoot -ChildPath 'Zoom Workplace Installer.msi'
$logPath = Join-Path -Path $env:TEMP -ChildPath ('DemoInstall-{0}.log' -f [guid]::NewGuid())

try {
    if (-not (Test-Path -LiteralPath $installerPath -PathType Leaf)) {
        throw "MSI not found: $installerPath"
    }

    Write-Host 'Starting Zoom Workplace Installer.msi. Review the Windows UAC prompt to continue.'
    Write-Host "Installer log: $logPath"
    $arguments = '/i "{0}" /norestart /L*v "{1}"' -f $installerPath, $logPath
    $process = Start-Process -FilePath "$env:SystemRoot\System32\msiexec.exe" `
        -ArgumentList $arguments -WorkingDirectory $PSScriptRoot `
        -Verb RunAs -Wait -PassThru
    $installerExitCode = $process.ExitCode

    if ($installerExitCode -eq 0) {
        Write-Host 'Installer completed successfully.'
    } elseif ($installerExitCode -eq 3010) {
        Write-Host 'Installer completed successfully; restart required.'
    } else {
        Write-Warning "Windows Installer exited with code $installerExitCode. See log: $logPath"
    }
    exit $installerExitCode
} catch {
    Write-Host ("Installation could not start: " + $_.Exception.Message) -ForegroundColor Red
    Write-Host 'Check the MSI filename and whether the UAC prompt was cancelled.'
    exit 1
}
